package com.library.repository;

public class BookRepository{
    public void displayBook(){
        System.out.println("Book: Spring in Action");
    }
}