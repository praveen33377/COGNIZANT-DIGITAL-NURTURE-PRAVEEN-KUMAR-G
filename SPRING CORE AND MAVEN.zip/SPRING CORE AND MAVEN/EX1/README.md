# LibraryManagement - Spring Exercise

This is a simple Spring Core project made for the library management exercise.

## What I did
- Created a Maven project named LibraryManagement.
- Added Spring Core dependency in the pom.xml file.
- Created applicationContext.xml to define the beans.
- Created BookRepository and BookService classes.
- Created a main class to test the Spring configuration.

## Main class run
Run this command from the project folder:

mvn exec:java -Dexec.mainClass=com.library.app.LibraryApp

## Expected output
Library app started successfully.
Book repository is ready for library operations.
