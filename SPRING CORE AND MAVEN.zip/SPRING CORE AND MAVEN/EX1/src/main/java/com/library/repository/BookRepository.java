package com.library.repository;

public class BookRepository {
    public String getBookDetails() {
        return "Book repository is ready for library operations.";
    }
}
