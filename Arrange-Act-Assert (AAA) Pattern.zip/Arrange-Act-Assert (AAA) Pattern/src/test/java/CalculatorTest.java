import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CalculatorTest {

    private Calculator calculator;

    // Setup Method (Runs before every test)
    @BeforeEach
    void setUp() {
        System.out.println("Setting up Calculator...");
        calculator = new Calculator();
    }

    // Test 1 - AAA Pattern
    @Test
    void testAddition() {

        // Arrange
        int num1 = 10;
        int num2 = 5;

        // Act
        int result = calculator.add(num1, num2);

        // Assert
        assertEquals(15, result);
    }

    // Test 2 - AAA Pattern
    @Test
    void testMultiplication() {

        // Arrange
        int num1 = 4;
        int num2 = 6;

        // Act
        int result = calculator.multiply(num1, num2);

        // Assert
        assertEquals(24, result);
    }

    // TearDown Method (Runs after every test)
    @AfterEach
    void tearDown() {
        System.out.println("Test Completed.");
    }
}