import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CalculatorTest {

    private Calculator calculator;

    @BeforeEach
    void setUp() {
        calculator = new Calculator();
        System.out.println("Setup: Calculator object created.");
    }

    @Test
    void testAddition1() {
        assertEquals(15, calculator.add(10, 5));
    }

    @Test
    void testAddition2() {
        assertEquals(30, calculator.add(20, 10));
    }

    @AfterEach
    void tearDown() {
        calculator = null;
        System.out.println("Teardown: Resources cleaned up.");
    }
}