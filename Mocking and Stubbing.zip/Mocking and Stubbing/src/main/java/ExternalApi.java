public interface ExternalApi {

    String getUserName();
}