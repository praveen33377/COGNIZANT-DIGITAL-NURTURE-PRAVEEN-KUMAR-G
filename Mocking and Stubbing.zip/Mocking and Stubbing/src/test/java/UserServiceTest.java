import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class UserServiceTest {

    @Test
    void testMockingAndStubbing() {

        // Arrange
        ExternalApi mockApi = mock(ExternalApi.class);

        when(mockApi.getUserName()).thenReturn("Praveen");

        UserService service = new UserService(mockApi);

        // Act
        String result = service.fetchUserName();

        // Assert
        assertEquals("Praveen", result);
    }
}