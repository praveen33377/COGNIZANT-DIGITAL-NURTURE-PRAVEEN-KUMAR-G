import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CalculatorTest {

    Calculator calculator = new Calculator();

    @Test
    void testAddition() {
        assertEquals(15, calculator.add(10, 5));
    }

    @Test
    void testSubtraction() {
        assertEquals(5, calculator.subtract(10, 5));
    }

    @Test
    void testMultiplication() {
        assertEquals(50, calculator.multiply(10, 5));
    }

    @Test
    void testNotEquals() {
        assertNotEquals(20, calculator.add(10, 5));
    }

    @Test
    void testTrue() {
        assertTrue(10 > 5);
    }

    @Test
    void testFalse() {
        assertFalse(5 > 10);
    }

    @Test
    void testNull() {
        String value = null;
        assertNull(value);
    }

    @Test
    void testNotNull() {
        assertNotNull(calculator.getObject());
    }

    @Test
    void testMessage() {
        assertEquals("Welcome to JUnit 5", calculator.getMessage());
    }
}