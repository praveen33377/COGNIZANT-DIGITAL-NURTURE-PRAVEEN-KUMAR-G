public class Calculator {

    public int add(int a, int b) {
        return a + b;
    }

    public int subtract(int a, int b) {
        return a - b;
    }

    public int multiply(int a, int b) {
        return a * b;
    }

    public String getMessage() {
        return "Welcome to JUnit 5";
    }

    public Object getObject() {
        return new Object();
    }
}