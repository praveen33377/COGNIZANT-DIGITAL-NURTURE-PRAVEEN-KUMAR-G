import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

public class UserRepositoryTest {

    @Test
    void testVerifyInteraction() {
        UserRepository repository = mock(UserRepository.class);
        repository.saveUser("Praveen");
        verify(repository).saveUser("Praveen");
    }
}