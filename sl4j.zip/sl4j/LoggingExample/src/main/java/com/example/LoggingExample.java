package com.example;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoggingExample {

    private static final Logger log =
            LoggerFactory.getLogger(LoggingExample.class);

    public static void main(String[] args) {

        log.warn("Warning : Check the entered data.");
        log.error("Error : Unable to process the request.");
    }
}