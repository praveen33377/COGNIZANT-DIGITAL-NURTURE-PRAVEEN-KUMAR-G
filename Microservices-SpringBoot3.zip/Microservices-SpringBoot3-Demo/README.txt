Template project for Cognizant Digital Nurture 5.0

This archive contains only a starter structure because a complete runnable
Spring Boot 3 + Spring Cloud Gateway multi-module project exceeds the size
that can be generated reliably in a single response.

Projects:
- account-service
- loan-service
- api-gateway

Populate each project with its pom.xml, application files and source code.
